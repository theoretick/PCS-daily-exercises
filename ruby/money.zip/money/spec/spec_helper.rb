require 'minitest/spec'
require 'minitest/autorun'

# local requires
require 'money'

# ENV['RUBY_ENV'] = 'test'