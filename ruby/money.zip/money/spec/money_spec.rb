# require 'spec_helper'
require 'minitest/spec'
require 'minitest/autorun'
# not sure, try this: https://github.com/CapnKernul/minitest-reporters
# require "minitest/reporters"
# MiniTest::Reporters.use! [MiniTest::Reporters::SpecReporter]
require './lib/money'

describe Money do
  it "should do something or other" do
    "hi".must_equal('hi')
  end

  describe "Working with USD" do
    before do
      @cash = "USD"
    end
  end

  describe "Working with GBP" do

  end
end

describe "Money when exchanging rates" do

end