$LOAD_PATH.unshift(File.expand_path(File.dirname(__FILE__))) unless $LOAD_PATH.include?(File.expand_path(File.dirname(__FILE__)))

require 'money'


# unless ENV['RUBY_ENV'] == 'test'
loop do
  puts "Eh sonny?"
  # whatever I want
  input = gets
  if Grandma.speak(input) == false
    break
  end

# rescue StandardError, EOIntException => e
# rescue Exception => e # NEVER!!!
end
# end